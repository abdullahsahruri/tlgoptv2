# Benchmarks
A collection of ISCAS85, ISCAS89, ITC99, TAU and other Benchmark Circuits.


## Useful links:
https://people.engr.ncsu.edu/brglez/CBL/benchmarks/Benchmarks-upto-1996.html  
https://people.engr.ncsu.edu/brglez/CBL/benchmarks/Mutants97/index.html  
https://ddd.fit.cvut.cz/prj/Benchmarks/  
http://web.eecs.umich.edu/~jhayes/iscas.restore/  
http://pld.ttu.ee/~maksim/benchmarks/
